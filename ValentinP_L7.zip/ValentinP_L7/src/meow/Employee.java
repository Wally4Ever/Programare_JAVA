package meow;

import java.util.Comparator;

class SortComparator implements Comparator<Employee> {

	public int compare(Employee o1, Employee o2) {
		if (o1.getName() != o2.getName()) {
			o1.getName().compareTo(o2.getName());
		}
		return o2.getSalar() - o1.getSalar();
	}

}

public class Employee implements Comparable<Employee> {
	private String name;
	private int age;
	private int salar;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getSalar() {
		return salar;
	}

	public void setSalar(int salar) {
		this.salar = salar;
	}

	@Override
	public int compareTo(Employee o) {
		if (this.getSalar() != o.getSalar()) {
			return (int) (o.getSalar() - this.getSalar());
		} else {
			return o.getName().compareTo(this.getName());
		}
	}
}
