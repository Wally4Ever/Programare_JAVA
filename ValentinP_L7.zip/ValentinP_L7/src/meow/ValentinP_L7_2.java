package meow;

/*Write a class called Calculator which has the methods to do addition, subtraction, multiplication and division. The 
methods will take generic input variables and will return the corresponding type. For example, the sum of two integers 
should return an integer, and for floats it should return a float. Same for division. Adding and subtracting is allowed for 
String variables as well, but the multiplication and division will print an error message.
Write the same class, but use method overloading.*/
public class ValentinP_L7_2 {
	public static void main(String[] args) {
		Calculator obj = new Calculator();
		System.out.println("Addition: " + obj.add("Ana are multe mere", " si le mananca"));
		System.out.println("Subtraction: " + obj.minus("Ana are multe mere", "e"));
		System.out.println("Multiplication 5*6: " + obj.multiply(5, 6));
		System.out.println("Division 8/2: " + obj.divide(8, 2));
	}
}

class Calculator<T> {

	public static <T> T add(T a, T b) {
		if (a == null || b == null) {
			throw new IllegalArgumentException("Inputs cannot be null");
		}

		if (a instanceof Integer && b instanceof Integer) {
			return (T) Integer.valueOf(((Integer) a).intValue() + ((Integer) b).intValue());

		} else if (a instanceof Float && b instanceof Float) {
			return (T) Float.valueOf(((Float) a).floatValue() + ((Float) b).floatValue());

		} else if (a instanceof String && b instanceof String) {
			return (T) (a.toString() + b.toString());

		} else {
			throw new IllegalArgumentException("Both int, float, or String");
		}
	}

	public static <T> T minus(T a, T b) {
		if (a == null || b == null) {
			throw new IllegalArgumentException("Inputs cannot be null");
		}

		if (a instanceof Integer && b instanceof Integer) {
			return (T) Integer.valueOf(((Integer) a).intValue() - ((Integer) b).intValue());

		} else if (a instanceof Float && b instanceof Float) {
			return (T) Float.valueOf(((Float) a).floatValue() - ((Float) b).floatValue());

		} else if (a instanceof String && b instanceof String) {
			if (a.toString().contains(b.toString())) {
				return (T) new String(a.toString().replaceAll(b.toString(), ""));
			} else {
				throw new IllegalArgumentException("ERROR: String 1 does not contain string 2!");
			}
		} else
			throw new IllegalArgumentException("Both int, float, or String");
	}

	public static <T> T multiply(T a, T b) {
		if (a == null || b == null) {
			throw new IllegalArgumentException("Inputs cannot be null");
		}

		if (a instanceof Integer && b instanceof Integer) {
			return (T) Integer.valueOf(((Integer) a).intValue() * ((Integer) b).intValue());

		} else if (a instanceof Float && b instanceof Float) {
			return (T) Float.valueOf(((Float) a).floatValue() * ((Float) b).floatValue());

		} else {
			throw new IllegalArgumentException("Both int, float");
		}
	}

	public static <T> T divide(T a, T b) {
		if (a == null || b == null) {
			throw new IllegalArgumentException("Inputs cannot be null");
		}

		if (a instanceof Integer && b instanceof Integer) {
			return (T) Integer.valueOf(((Integer) a).intValue() / ((Integer) b).intValue());

		} else if (a instanceof Float && b instanceof Float) {
			return (T) Float.valueOf(((Float) a).floatValue() / ((Float) b).floatValue());

		} else {
			throw new IllegalArgumentException("Both int, float");
		}
	}
}