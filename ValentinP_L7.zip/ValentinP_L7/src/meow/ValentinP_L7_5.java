package meow;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

/*Write a class named Student that has the private fields name, group, average_mark, and getter / setter methods for
all the attributes. In the main() method, placed in another class, create a sortedSet collection, with Student type objects, 
initialized with values read from the keyboard, that will keep the elements in descending order by average_mark and in 
ascending order by name (the students that have the same average will appear in alphabetic order). Browse the 
collection using for-loop and display all the items. Then browse the collection with an iterator and display all students 
with average_mark> = 8. Browse the collection with forEach () and display all student data in a particular group.
*/
public class ValentinP_L7_5 {
	private static Scanner kb;

	public static void main(String[] args) {
		Set<Student> students = addStudents();
		show(students);
	}

	private static Set<Student> addStudents() {
		Random rand = new Random();
		int nr = rand.nextInt(4) + 1;
		System.out.println("Enter name: ");
		String name;
		int gr;
		double avg;
		kb = new Scanner(System.in);
		try {
			Set<Student> stud = new HashSet<>();

			for (int i = 0; i < nr; i++) {
				System.out.print("\nStudent[" + (i + 1) + "]\nName: ");
				name = kb.next();
				gr = rand.nextInt(4) + 1;
				avg = rand.nextDouble(6) + 4;

				Student aux = new Student();
				aux.setName(name);
				aux.setGr(gr);
				aux.setAvg(avg);
				stud.add(aux);
			}
			return stud;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static void show(Set<Student> set) {
		try {
			if (set.size() == 0)
				throw new Exception("No students!");

			for (Student i : set) {
				System.out.println("\nName: " + i.getName());
				System.out.println("Gr: " + i.getGr());
				System.out.println("Avg: " + i.getAvg());
			}

			Iterator<Student> itr = set.iterator();
			System.out.println("\nStudents with grades >=8 ");
			while (itr.hasNext()) {
				Student x = itr.next();

				if (x.getAvg() >= 8) {
					System.out.print(x.getName() + " ");
				}
			}

			System.out.println("\n\nStudents that are from group 3: ");
			set.forEach((n) -> { // getting all the students from certain group
				if (n.getGr() == 3)
					System.out.print(n.getName() + " ");
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class Student implements Comparable<Student> {
	private String name;
	private int gr;
	private double avg;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getGr() {
		return gr;
	}

	public void setGr(int gr) {
		this.gr = gr;
	}

	public double getAvg() {
		return avg;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}

	@Override
	public int compareTo(Student o) {
		if (this.getAvg() != o.getAvg()) {
			return (int) (o.getAvg() - this.getAvg());
		} else {
			return o.getName().compareTo(this.getName());
		}
	}
}