package meow;

/*Create an interface called Generator<T> with a single method next(T var). Implement the interface so that you can 
generate the following values when applying it to certain data types (Integer, Character, etc.). The class will be 
instantiated in the main( ) method, located in a separate class.*/
public class ValentinP_L7_1 {
	public static void main(String[] args) {
		ValueGenerator gen = new ValueGenerator();

		Integer nextInteger = gen.next(5);
		System.out.println("Next Integer value: " + nextInteger);

		Character nextChar = gen.next('a');
		System.out.println("Next Character value: " + nextChar);
	}

}

interface Generator<T> {
	T next(T var);

}

class ValueGenerator implements Generator {

	public Integer next(Integer var) {
		return var + 1;
	}

	public Character next(Character var) {
		return (char) (var + 1);
	}

	public Object next(Object var) {
		// TODO Auto-generated method stub
		return null;
	}

}
