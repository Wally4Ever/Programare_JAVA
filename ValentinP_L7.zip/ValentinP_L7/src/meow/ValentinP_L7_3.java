package meow;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

/*. Build an application which contains a generic class SetterGetter which allows the user to set() and get() the attribute 
values for different types of objects. For example, given the classes Kid, Adult and Retired, enable the class to set and get 
the names and ages of the associated objects. Create collections with unique entries of type Kid and Adult, and 
which are populated with data read from the console. Print the read data using different methods*/
public class ValentinP_L7_3 {
	private static Scanner kb;

	public static void main(String[] args) {
		Set<Adult> adults = createAdult();
		Set<Kid> kids = createKid();

		for (Adult a : adults)
			System.out.println(a);
		show(adults);

		Object[] kidArr = kids.toArray();
		SetterGetter obj = new SetterGetter();
		for (int i = 0; i < kidArr.length; i++) {
			System.out.println(obj.getName((Human) kidArr[i]) + " " + obj.getAge((Human) kidArr[i]));
		}
		show(kids);

	}

	private static void show(Set<? extends Human> set) {

		if (set instanceof Kid)
			System.out.println("Kids:");
		else if (set instanceof Adult)
			System.out.println("Adults:");

		try {
			if (set.size() == 0)
				throw new Exception("This is null");
			SetterGetter obj = new SetterGetter();

			for (Human instanceOfSet : set) {
				System.out.println("\nName: " + obj.getName(instanceOfSet));
				System.out.println("Age: " + obj.getAge(instanceOfSet));
			}

		} catch (Exception ex) {
			System.out.println("\nSomething went wrong!");
		}
	}

	private static Set<Adult> createAdult() {
		System.out.println("Nr. of adults: ");
		kb = new Scanner(System.in);
		int nr = kb.nextInt();
		SetterGetter obj = new SetterGetter();
		Set<Adult> adults = new HashSet<>();

		System.out.println("Enter name and age: ");
		String name;
		int age;

		try {
			for (int i = 0; i < nr; i++) {
				System.out.print("\nAdult[" + (i + 1) + "]\nName: ");
				name = kb.next();
				System.out.print("Age: ");
				age = kb.nextInt();

				Adult aux = new Adult();
				obj.setAge(aux, age);
				obj.setName(aux, name);
				adults.add(aux);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			return adults;
		}
	}

	private static Set<Kid> createKid() {
		System.out.println("Nr. of kids: ");
		kb = new Scanner(System.in);
		int nr = kb.nextInt();
		SetterGetter obj = new SetterGetter();
		Set<Kid> kids = new HashSet<>();

		System.out.println("Enter name and age: ");
		String name;
		int age;

		try {
			for (int i = 0; i < nr; i++) {
				System.out.print("\nKid[" + (i + 1) + "]\nName: ");
				name = kb.next();
				System.out.print("Age: ");
				age = kb.nextInt();

				Kid aux = new Kid();
				obj.setAge(aux, age);
				obj.setName(aux, name);
				kids.add(aux);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			return kids;
		}
	}
}

class Human {
	private String name;
	private int age;

	public Human() {
		this.setName("Popescu");
		this.setAge(99);
	}

	public Human(String name, int age) {
		this.setName(name);
		this.setAge(age);
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

class Kid extends Human {

	public Kid() {
		super();
	}

	public Kid(String name, int age) {
		super(name, age);
	}

}

class Adult extends Human {

	public Adult() {
		super();
	}

	public Adult(String name, int age) {
		super(name, age);
	}

	@Override
	public String toString() {
		return this.getName() + " " + this.getAge();
	}

}

class SetterGetter<T extends Human> {

	public void setName(T x, String name) {
		x.setName(name);
	}

	public String getName(T x) {
		return x.getName();
	}

	public void setAge(T x, int age) {
		x.setAge(age);
	}

	public int getAge(T x) {
		return x.getAge();
	}
}
