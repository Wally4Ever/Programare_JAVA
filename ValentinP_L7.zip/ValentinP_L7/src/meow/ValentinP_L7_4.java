package meow;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Scanner;

/*Implement a class called UserFile (name, extension, type, size in bytes, constructors, mutators, accesors). The types of 
files are predefined and stored in a Hashtable object (for example "image"->0, "text"->1, "application"->2, etc.) Create a 
list of objects from this class and read from the keyboard the associated info. Print all the specific extensions of the 
predefined file types. Order the file list based on size and print the result.*/
public class ValentinP_L7_4 {
	private static Scanner kb;

	public static void main(String[] args) {
		ArrayList<UserFile> files = addFiles();
		show(files);
	}

	private static ArrayList<UserFile> addFiles() {
		ArrayList<UserFile> files = new ArrayList<UserFile>();
		Scanner kb = new Scanner(System.in);
		System.out.print("Enter number of files: ");
		String name, extension, type;
		int size;
		boolean ok = true;
		try {
			int nr = kb.nextInt();

			for (int i = 0; i < nr; i++) {
				System.out.print("\nFile " + (i + 1) + "\nName: ");
				name = kb.next();
				System.out.print("Extension: ");
				extension = kb.next();
				System.out.print("Type (img, txt or app): ");
				type = kb.next();
				ok = true;
				Hashtable<Integer, String> tableType = new Hashtable<>();
				switch (type) {
				case "img": {
					tableType.put(0, type);
					break;
				}
				case "txt": {
					tableType.put(1, type);
					break;
				}
				case "app": {
					tableType.put(2, type);
					break;
				}
				default: {
					System.out.println("Not valid!");
					i--;
					ok = false;
				}
				}
				if (ok) {
					System.out.print("Enter file size in bytes: ");
					size = kb.nextInt();
					UserFile object = new UserFile(name, extension, tableType, size);
					files.add(object);
				}
			}
			kb.close();
			return files;
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}

	private static void show(ArrayList<UserFile> list) {
		System.out.println("List: ");
		Collections.sort(list);
		for (UserFile userfile : list) {
			System.out.println("\nFile name: " + userfile.getName());
			System.out.println("File size: " + userfile.getSizeInBytes());
		}
	}
}

class UserFile implements Comparable<UserFile> {
	String name;
	String extension;
	private Hashtable<Integer, String> type;
	int sizeInBytes;

	public String getName() {
		return name;
	}

	public UserFile(String name, String extension, Hashtable<Integer, String> type, int sizeInBytes) {
		this.name = name;
		this.extension = extension;
		this.type = type;
		this.sizeInBytes = sizeInBytes;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public int getSizeInBytes() {
		return sizeInBytes;
	}

	public void setSizeInBytes(int sizeInBytes) {
		this.sizeInBytes = sizeInBytes;
	}

	public Hashtable<Integer, String> getType() {
		return type;
	}

	public void setType(Hashtable<Integer, String> type) {
		this.type = type;
	}

	@Override
	public int compareTo(UserFile o) {
		if (this.getSizeInBytes() != o.getSizeInBytes()) {
			return this.getSizeInBytes() - o.getSizeInBytes();
		} else {
			return this.getName().compareTo(o.getName());
		}
	}

//	@Override
//	public int compareTo(UserFile object) {
//		if (this.getSizeInBytes() != object.getSizeInBytes()) {
//			return this.getSizeInBytes() - object.getSizeInBytes();
//		} else {
//			return this.getName().compareTo(object.getName());
//		}
//	}
}
