package meow;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;

/*Write an Employee class with the private fields name, age, salary and getter / setter methods for the fields. In the 
main () method, placed in another class, create a list of Employee type objects, initialized with values read from the 
keyboard. Sort the the list in:
- ascending order by name, using the Comparable interface
- descending order by age, using the Comparable interface and a lambda expression
- ascending order by name and descending order by salary, using the Comparator interface

*/
public class ValentinP_L7_6 {

	private static Scanner kb;

	public static void main(String[] args) {
		ArrayList<Employee> employ = addEmployees();
		show(employ);
		Collections.sort(employ);
		System.out.print("\nList after sorting: ");
		show(employ);

		System.out.print("\nName and salary sort:");
		Collections.sort(employ, new SortComparator());
		show(employ);

		System.out.println("\nAge sort: ");
		Comparator<Employee> c2 = (Employee o1, Employee o2) -> o2.getAge() - o1.getAge();
		Collections.sort(employ, c2);
		show(employ);
	}

	private static ArrayList<Employee> addEmployees() {
		Random rand = new Random();
		int nr = rand.nextInt(4) + 1;
		System.out.println("Enter name: ");
		String name;
		int age;
		int salar;
		kb = new Scanner(System.in);
		try {
			ArrayList<Employee> emp = new ArrayList<Employee>();

			for (int i = 0; i < nr; i++) {
				System.out.print("\nEmployee[" + (i + 1) + "]\nName: ");
				name = kb.next();
				age = rand.nextInt(30) + 18;
				salar = rand.nextInt(500) + 2500;

				Employee aux = new Employee();
				aux.setName(name);
				aux.setAge(age);
				aux.setSalar(salar);
				emp.add(aux);
			}
			return emp;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static void show(ArrayList<Employee> set) {
		try {
			if (set.size() == 0)
				throw new Exception("No empents!");

			for (Employee i : set) {
				System.out.println("\nName: " + i.getName());
				System.out.println("Age: " + i.getAge());
				System.out.println("Salary: " + i.getSalar());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}