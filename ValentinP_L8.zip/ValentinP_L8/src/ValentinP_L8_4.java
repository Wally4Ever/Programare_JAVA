import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/*You are given a binary file which contains a sequence of characters representing a private Bitcoin key (256 characters).
From the keyboard read a sequence of characters which represents the public key for a Bitcoin. Generate the
transaction id for this information by using the XOR bitwise operator applied upon the private and public keys. Write the
result in another binary file. */
public class ValentinP_L8_4 {
	private static Scanner kb;

	public static void main(String[] args) {

		kb = new Scanner(System.in);
		System.out.println("Input BTC key: ");
		String keyPublic = kb.nextLine();
		byte[] keyPublicBytes = keyPublic.getBytes();

		Path keyPrivate = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\in.txt");
		byte[] keyPrivateBytes;

		try {
			keyPrivateBytes = Files.readAllBytes(keyPrivate);
		} catch (IOException e) {
			System.out.println("File err");
			return;
		}
		byte[] idBytes = new byte[256];
		for (int i = 0; i < 256; i++) {
			idBytes[i] = (byte) (keyPrivateBytes[i] ^ keyPublicBytes[i % keyPublicBytes.length]);
		}

		Path idPath = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\out.txt");
		try {
			Files.write(idPath, idBytes);
			System.out.println("Transaction ID generated and written to file.");
		} catch (IOException e) {
			System.out.println("Error writing transaction ID to file.");
		}
	}
}
