import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/*You are given a *.csv file which contains the following fields separated by the "/" symbol: name, surname, phone
number, date of birth. Read the information in the file and generate individual files containing
the following information: people born in December, people whose phone numbers are international (not Romanian) or
are landline numbers, people named Andrei and Nicolae
*/
public class ValentinP_L8_6 {
	public static void main(String[] args) {
		Path in = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\input.csv");
		Path phone = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\telefon.txt");
		Path nume = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\nume.txt");
		Path decembrie = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\decembrie.txt");

		try {
			List<String> lines = Files.readAllLines(in);
			for (String line : lines) {

				String[] fields = line.split("/");
				String name = fields[0];
				String telefon = fields[1];
				String data = fields[2];
				if (data.contains(".12.")) {
					toFile(decembrie, name);
				}
				if (!telefon.startsWith("40")) {
					toFile(phone, name);
				}
				if (name.equalsIgnoreCase("Andrei") || name.equalsIgnoreCase("Nicolae")) {
					toFile(nume, name);
				}
			}
			;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void toFile(Path file, String name) {
		try {
			Files.write(file, (name + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
					java.nio.file.StandardOpenOption.APPEND);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
