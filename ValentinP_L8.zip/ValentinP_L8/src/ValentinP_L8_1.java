import static java.io.StreamTokenizer.TT_EOL;
import static java.io.StreamTokenizer.TT_NUMBER;
import static java.io.StreamTokenizer.TT_WORD;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;

/*Using a KB reading mechanism (BufferedReader/InputStreamReader) input: a message of String type, a day as an
integer, a month as a String and a year as an integer variable. The process will end by passing to a new line, or by typing
a special String. Separate and display the tokens on different rows. Display all fields extracted from the stream as
appeared.
Recommendation: use the StreamTokenizer class, the attributes sval, nval and the TT_EOL constant.
Consider the case in which the application is not aware of the entered data type (numbers, words). Use the constants
TT_NUMBER, TT_WORD.
*/
//TT_EOL does NOT work
public class ValentinP_L8_1 {
	public static void main(String[] args) {

		System.out.println("Enter a message, day, month and year (separated by spaces):");
		try {
			BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
			StreamTokenizer tok = new StreamTokenizer(buf);
			while (tok.nextToken() != TT_EOL) {
				if (tok.ttype == TT_WORD) {
					System.out.println("String: " + tok.sval);
				} else if (tok.ttype == TT_NUMBER) {
					System.out.println("Number: " + (int) tok.nval);
				} else if (tok.ttype == TT_EOL) {
					break;
				}
				// doesn't stop???
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			System.out.print("Done!");
		}
	}
}
