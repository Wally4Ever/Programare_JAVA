import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

/*Write a Java application which enables the serialization and deserialization of objects that represent arrays of int
values. Populate an object with keyboard entered data, order the values and store the object in a file. Read the file and
display the reconstructed array of values.*/
public class ValentinP_L8_7 {
	private static Scanner kb;

	public static void main(String[] args) throws IOException, ClassNotFoundException {

		Scanner kb = new Scanner(System.in);

		System.out.println("Enter elements separated by space:");
		String in = kb.nextLine();
		StringTokenizer st = new StringTokenizer(in, " ");
		int n = in.length() / 2 + 1;
		int[] arr = new int[n];
		int i = 0;
		while (st.hasMoreTokens()) {
			arr[i] = Integer.parseInt(st.nextToken());
			i++;
		}
		Arrays.sort(arr);
		Path path = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\out.txt");
		try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(path))) {
			out.writeObject(arr);
		} catch (IOException e) {
			System.err.println("Error writing object to file: " + e.getMessage());
		}
		try (ObjectInputStream input = new ObjectInputStream(Files.newInputStream(path))) {
			int[] rezult = (int[]) input.readObject();
			System.out.println("Deserialized array: " + Arrays.toString(rezult));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}