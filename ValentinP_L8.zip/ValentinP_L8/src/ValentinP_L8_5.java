import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* Write a Java application which reads a set of text files that contain students data (CSV files). The files are stored on the
local machine under the names Year_Y_Group_XXXX.txt . Agregate the information in these files using a
SequenceInputStream and generate a new file which contains all the students ordered alphabetically.*/
public class ValentinP_L8_5 {

	public static void main(String[] args) throws IOException {
		List<String> students = new ArrayList<>();

		Path folder = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\students");

		try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(folder, "*_*txt")) {
			for (Path filePath : directoryStream) {
				Files.readAllLines(filePath).forEach(students::add);
			}
		}
		Collections.sort(students);

		Path outputPath = Paths.get("E:\\POLI\\Programare\\ValentinP_L8\\src\\students\\compilat.txt");
		Files.write(outputPath, students);
	}
}
