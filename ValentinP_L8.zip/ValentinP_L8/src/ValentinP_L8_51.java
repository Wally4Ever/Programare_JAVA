import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;

public class ValentinP_L8_51 {
	public static void main(String[] args) throws IOException {
		File folder = new File("E:\\POLI\\Programare\\ValentinP_L8\\src\\students");
		File[] allFiles = folder.listFiles();
		File compiledFile = new File("E:\\POLI\\Programare\\ValentinP_L8\\src\\students\\compilat.txt");
		// 2022_Cristi
		// 2023_Trifan
		try {
			compiledFile.createNewFile();
			if (allFiles != null) {
				PrintWriter printWriter = new PrintWriter(new FileWriter(compiledFile, true));
				for (File file : allFiles) {
					if (file.getName().matches("\\d+_[a-zA-Z]+\\.txt")) {

						String name = new String(Files.readAllBytes(Paths.get(file.toURI())));
						String group = file.getName().substring(0, 4); // only group

						printWriter.append("Students from GROUP " + group + ":\n");
						printWriter.append(name);
						printWriter.append("\n");
						System.out.println("Students from GROUP " + group + ":\n" + name + "\n");
					}
				}
				printWriter.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
