
/* Implement the previous problem using a file as input source.*/

import static java.io.StreamTokenizer.TT_EOF;
import static java.io.StreamTokenizer.TT_NUMBER;
import static java.io.StreamTokenizer.TT_WORD;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.StreamTokenizer;

// TT_EOL does NOT work
public class ValentinP_L8_2 {
	public static void main(String[] args) {

		System.out.println("Enter a message, day, month and year (separated by spaces):");
		try {
			BufferedReader buf = new BufferedReader(new FileReader("E:\\POLI\\Programare\\ValentinP_L8\\src\\in.txt"));
			StreamTokenizer tok = new StreamTokenizer(buf);
			while (tok.nextToken() != TT_EOF) {
				if (tok.ttype == TT_WORD) {
					System.out.println("String: " + tok.sval);
				} else if (tok.ttype == TT_NUMBER) {
					System.out.println("Number: " + (int) tok.nval);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			System.out.print("Done!");
		}
	}
}
