
/* Read from the keyboard some strings representing dates formated as DD/MM/YYYY. Print the dates as DD month
YYYY, where month is the expanded version of the MM, and also display messages if the year is leap. The program exits
when the user types in X or x from KB. You may use DateFormatSymbols class for month conversion.
*/
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class ValentinP_L8_3 {

	private static Scanner kb;

	public static void main(String[] args) {
		kb = new Scanner(System.in);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		DateFormatSymbols symbols = new DateFormatSymbols();
		String[] months = symbols.getMonths();

		while (true) {
			System.out.print("Enter DD/MM/YYYY (X to exit): ");
			String in = kb.nextLine();

//			if (in.charAt(0) == 'x' || in.charAt(0) == 'X') {
//				break;
//			}
			if (in.equalsIgnoreCase("x")) {
				break;
			}
			try {
				Date date = dateFormat.parse(in);
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(date);

				int day = calendar.get(Calendar.DAY_OF_MONTH);
				int monthNr = calendar.get(Calendar.MONTH);
				String month = months[monthNr];
				int year = calendar.get(Calendar.YEAR);

				System.out.printf("%d %s %d%n", day, month, year);

				if (isLeapYear(year)) {
					System.out.println("The year is a leap year.");
				} else {
					System.out.println("The year is not a leap year.");
				}
			} catch (ParseException e) {
				System.out.println("Invalid date format.");
			} finally {
				System.out.println("Finally!");
			}
		}

	}

	private static boolean isLeapYear(int year) {
		if (year % 4 != 0) {
			return false;
		} else if (year % 100 != 0) {
			return true;
		} else if (year % 400 != 0) {
			return false;
		} else {
			return true;
		}
	}

}
