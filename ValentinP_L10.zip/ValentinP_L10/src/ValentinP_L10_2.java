import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;

/*Write a Frame application that will draw, inside a Canvas component, a circle tangent to smaller side of the canvas.*/
public class ValentinP_L10_2 extends JFrame {

	public ValentinP_L10_2() {
		setSize(500, 500);
		Canvas canvas = new Canvas() {

			public void paint(Graphics g) {
				super.paint(g);
				Dimension size = getSize();
				int width = size.width;
				int height = size.height;

				int radius = Math.min(width, height) / 2;

				int x = (width - radius) / 2;
				int y = (height - radius) / 2;

				g.setColor(Color.BLUE);
				g.drawOval(x, y, radius, radius);
			}
		};
		canvas.setBackground(new Color(255, 255, 128));
		getContentPane().add(canvas, BorderLayout.CENTER);
		setVisible(true);
	}

	public static void main(String[] args) {
		new ValentinP_L10_2();
	}
}
