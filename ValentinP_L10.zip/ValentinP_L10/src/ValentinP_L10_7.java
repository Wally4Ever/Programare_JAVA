import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;

/*mplement a Frame application that fills a visual container with circles having randomly generated radii. The circles
are tangent and have random colors.
*/
public class ValentinP_L10_7 extends JFrame {

	private final JPanel circlePanel;

	public ValentinP_L10_7() {
		circlePanel = new JPanel() {

			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				int width = getWidth();
				int height = getHeight();
				Random rand = new Random();

				int x = 0, y = 0;
				int radius = 0;
				Color color = null;
				while (y < height) {
					radius = rand.nextInt(50) + 10;
					x = radius + rand.nextInt(width - radius * 2);
					y += radius * 2;
					color = new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256));
					g.setColor(color);
					g.fillOval(x - radius, y - radius, radius * 2, radius * 2);
				}
			}
		};

		add(circlePanel);

		setTitle("Circle Container");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(600, 400));
		pack();
		setVisible(true);
	}

	public static void main(String[] args) {
		new ValentinP_L10_7();
	}
}
