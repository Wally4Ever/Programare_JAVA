import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

/*Write a Frame application that draws a schematic car. Use different colors for different car parts (doors, wheels, etc.).*/
public class ValentinP_L10_6 extends JFrame {

	private final JPanel carPanel;

	public ValentinP_L10_6() {
		// create the car panel
		carPanel = new JPanel() {

			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				int width = getWidth();
				int height = getHeight();

				// set the colors for the car parts
				Color bodyColor = new Color(255, 153, 51);
				Color roofColor = new Color(0, 102, 204);
				Color windowColor = new Color(153, 204, 255);
				Color wheelColor = new Color(51, 51, 51);

				// draw the car parts
				g.setColor(bodyColor);
				g.fillRect(width / 8, height / 4, width * 3 / 4, height / 2);
				g.setColor(roofColor);
				g.fillRect(width / 4, height / 8, width / 2, height / 4);
				g.setColor(windowColor);
				g.fillRect(width / 4 + 5, height / 8 + 5, width / 2 - 10, height / 4 - 10);
				g.setColor(wheelColor);
				g.fillOval(width / 4 - height / 8, height * 3 / 4, height / 4, height / 4);
				g.fillOval(width * 3 / 4, height * 3 / 4, height / 4, height / 4);
			}
		};

		// add the car panel to the frame
		add(carPanel);

		// set the frame properties
		setTitle("Car Diagram");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setPreferredSize(new Dimension(600, 400));
		pack();
		setVisible(true);
	}

	public static void main(String[] args) {
		new ValentinP_L10_6();
	}
}
