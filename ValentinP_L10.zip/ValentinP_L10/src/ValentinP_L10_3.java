import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*Write a Frame application that displays an image stored in a local file. Below the image display the filename with a
predefined Font. The text is drawn using a color composed of 3 predefined components (red, green, blue).*/
public class ValentinP_L10_3 extends JFrame {

	public ValentinP_L10_3() {

		setSize(1000, 800);

		final ImagePanel imagePanel = new ImagePanel("E:\\POLI\\Programare\\ValentinP_L10\\src\\cat.jpg");

		JLabel filenameLabel = new JLabel(imagePanel.getFilename());
		filenameLabel.setFont(new Font("Arial", Font.PLAIN, 20));
		filenameLabel.setForeground(new Color(0, 5, 0));

		JPanel filenamePanel = new JPanel(new BorderLayout());
		filenamePanel.add(filenameLabel, BorderLayout.SOUTH);

		add(imagePanel, BorderLayout.CENTER);
		add(filenamePanel, BorderLayout.SOUTH);

		setVisible(true);
	}

	public static void main(String[] args) {
		new ValentinP_L10_3();
	}

	private class ImagePanel extends JPanel {
		private BufferedImage image;
		private String filename;

		public ImagePanel(String filename) {
			this.filename = filename;
			try {

				this.image = ImageIO.read(new File(filename));
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			setPreferredSize(new Dimension(image.getWidth(), image.getHeight()));
		}

		public String getFilename() {
			return filename;
		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);

			g.drawImage(image, 0, 0, null);
		}
	}
}