import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

/*Write a Frame application that displays a TV test card. The card will contain at least 10 levels of grey and the basic
colors red, green, blue, yellow, cyan and magenta. The card will cover the entire surface of the component that displays
it (Canvas, etc.).
*/
public class ValentinP_L10_4 extends JFrame {

	public ValentinP_L10_4() {
		// set the size of the frame
		setSize(920, 500);
		setExtendedState(Frame.MAXIMIZED_BOTH);

		// create a panel for the test card
		JPanel cardPanel = new JPanel() {

			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				int width = getWidth();
				int height = getHeight();

				int step = height / 11;
				for (int i = 0; i < 10; i++) {
					int greyLevel = (int) (255.0 * (i + 1) / 10.0);
					g.setColor(new Color(greyLevel, greyLevel, greyLevel));
					g.fillRect(0, i * step, width, step);
				}

				int colorStep = width / 6;
				g.setColor(Color.RED);
				g.fillRect(0, step * 10, colorStep, height - step * 10);
				g.setColor(Color.GREEN);
				g.fillRect(colorStep, step * 10, colorStep, height - step * 10);
				g.setColor(Color.BLUE);
				g.fillRect(colorStep * 2, step * 10, colorStep, height - step * 10);
				g.setColor(Color.YELLOW);
				g.fillRect(colorStep * 3, step * 10, colorStep, height - step * 10);
				g.fillRect(colorStep * 4, step * 10, colorStep, height - step * 10);
				g.setColor(Color.MAGENTA);
				g.fillRect(colorStep * 5, step * 10, colorStep, height - step * 10);

				g.setColor(Color.WHITE);
				g.setFont(new Font("Arial", Font.PLAIN, 20));
				g.drawString("TV Test Card", width / 2 - 60, height / 2 + 10);
			}
		};

		cardPanel.setPreferredSize(new Dimension(600, 400));

		add(cardPanel);

		setVisible(true);
	}

	public static void main(String[] args) {
		new ValentinP_L10_4();
	}
}
