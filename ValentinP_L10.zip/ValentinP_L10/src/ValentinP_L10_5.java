
/*Write a Frame application that draws a circle colored in all the possible colors. The starting color is red and the color
transitions must be made as smooth as possible.
*/
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class ValentinP_L10_5 extends JFrame {

	private final JPanel circlePanel;

	public ValentinP_L10_5() {
		circlePanel = new JPanel() {

			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				int width = getWidth();
				int height = getHeight();
				int diameter = Math.min(width, height) * 9 / 10;
				for (int i = 0; i < 360; i++) {
					float hue = (float) i / 360.0f;
					Color color = Color.getHSBColor(hue, 1.0f, 1.0f);

					g.setColor(color);

					double angle = Math.toRadians(i);
					int x = (int) (width / 2 + 0.45 * diameter * Math.cos(angle));
					int y = (int) (height / 2 + 0.45 * diameter * Math.sin(angle));
					int arcWidth = diameter / 10;
					int arcHeight = diameter / 10;

					g.fillArc(x, y, arcWidth, arcHeight, i, 1);
				}
			}
		};
		circlePanel.setBackground(new Color(0, 0, 0));

		getContentPane().add(circlePanel);

		setTitle("Rainbow Circle");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800, 800);
		setVisible(true);
	}

	public static void main(String[] args) {
		new ValentinP_L10_5();
	}
}
