import java.util.Arrays;
import java.util.Scanner;

/*Write a Java program that defines an array of double values and reads the appropriate data from the keyboard. Handle 
the exception produced when the code tries to access an element that has a negative index or an index greater than the 
maximum number of elements (ArrayIndexOutOfBoundsException). Display a significant message when the exception 
occurs. 
*/
public class ValentinP_L6_1 {
	private static Scanner kb;

	public static void main(String[] args) {
		kb = new Scanner(System.in);
		try {
			System.out.print("Number of elements: ");
			int n = kb.nextInt();

			double[] arr = new double[n];
			for (int i = 0; i < n; i++) {
				System.out.print("El " + i + 1 + ": ");
				arr[i] = kb.nextDouble();
			}
			System.out.println("Array: " + Arrays.toString(arr));

		} catch (Exception e) {
			System.out.println("Exception: " + e + "\n");
		}
		System.out.println("Program still executes.");
	}
}
