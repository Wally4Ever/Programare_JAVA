/*Write an application which checks if 3 random points form an obtuse triangle. If the condition is not met, a specific 
exception is thrown: AcuteTriangle, RightTriangle. If the 3 points are on the same line or if the segments determined by 
the 3 points cannot make up a triangle, throw an ImpossibleTriangle exception, and within the corresponding catch 
block print a warning and throw a RuntimeException.*/
public class ValentinP_L6_5 {
	public static void main(String[] args) {
		try {
			Point p1 = new Point(1, 1);
			Point p2 = new Point(0, 0);
			Point p3 = new Point(0, 8);

			Triangle t = new Triangle(p1, p2, p3);
			t.checkTriangleType();
		} catch (ImpossibleTriangle e) {
			System.out.println("Warning: " + e.getMessage());
			throw new RuntimeException(e);
		} catch (AcuteTriangle e) {

			e.printStackTrace();
		} catch (RightTriangle e) {

			e.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}
}

class ImpossibleTriangle extends Exception {
	public ImpossibleTriangle(String message) {
		super(message);
	}
}

class AcuteTriangle extends Exception {
	public AcuteTriangle(String message) {
		super(message);
	}
}

class RightTriangle extends Exception {
	public RightTriangle(String message) {
		super(message);
	}
}

class Point {
	private double x;
	private double y;

	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
}

class Triangle {
	private Point a;
	private Point b;
	private Point c;

	public Triangle(Point a, Point b, Point c) throws ImpossibleTriangle {
		double ab = distance(a, b);
		double bc = distance(b, c);
		double ac = distance(a, c);

		if (ab + bc <= ac || ab + ac <= bc || bc + ac <= ab) {
			throw new ImpossibleTriangle("The points do not form a triangle.");
		}
		this.a = a;
		this.b = b;
		this.c = c;
	}

	private double distance(Point p1, Point p2) {
		double dx = p1.getX() - p2.getX();
		double dy = p1.getY() - p2.getY();
		return Math.sqrt(dx * dx + dy * dy);
	}

	public static double calculateAngle(double side1, double side2, double side3) {
		double cosAngle = (Math.pow(side1, 2) + Math.pow(side2, 2) - Math.pow(side3, 2)) / (2 * side1 * side2);
		return Math.toDegrees(Math.acos(cosAngle));
	}

	public void checkTriangleType() throws AcuteTriangle, RightTriangle, ImpossibleTriangle {
		double ab = distance(a, b);
		double bc = distance(b, c);
		double ac = distance(a, c);
		int aAng = (int) calculateAngle(ab, bc, ac);
		int bAng = (int) calculateAngle(ac, ab, bc);
		int cAng = (int) calculateAngle(bc, ac, ab);

		if (aAng == 90 || cAng == 90 || bAng == 90) {
			throw new RightTriangle("right");

		} else if (aAng < 90 && bAng < 90 && cAng < 90) {

			throw new AcuteTriangle("acute");

		} else
			System.out.println("Obtuse");
	}
}
