import java.awt.Color;
import java.util.Random;

/*Write a Java application which implements an exception called OverSaturated. This exception is generated when the 
saturation of a color has a value over 90 in the HSV color space. Write a method which randomly generated colors in the 
RGB space and then converts them to the HSB/HSV space (https://www.cs.rit.edu/~ncs/color/t_convert.html). If after 
the conversion, the color's saturation is over 90, regenerate the color (In the testing phase, use an assertion 
to verify this 
internal invariant condition). After 10 consecutive tries to regenerate, throw an exception.
*/

public class ValentinP_L6_6 {
	public static void main(String[] args) {

		try {
			int i;
			for (i = 1; i <= 10; i++) {
				Random a = new Random();
				int x = a.nextInt(255);
				int y = a.nextInt(255);
				int z = a.nextInt(255);
				Color obj = new Color(x, y, z);

				System.out.println("Color is: " + obj.toString());
				float[] arr = new float[3];
				arr = obj.RGBtoHSB(x, y, z, null);
				if (arr[1] < 0.9) {
					System.out.println("Saturation: " + arr[1]);
					break;
				}

			}
			if (i == 11) {
				throw new OverSaturated("Error generating color");
			}

		} catch (OverSaturated e) {
			e.printStackTrace();
		}
	}
}

class OverSaturated extends Exception {
	public OverSaturated(String message) {
		super(message);
	}
}