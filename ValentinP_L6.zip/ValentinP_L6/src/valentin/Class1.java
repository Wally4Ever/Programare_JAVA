package valentin;

public abstract class Class1 implements Int1, Int2 {
	protected double a, b;

	public Class1(double a, double b) {
		this.a = a;
		this.b = b;
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	int sum(int a, int b) {
		return a * b;
	}
}