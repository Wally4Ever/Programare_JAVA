package valentin;

public interface Int2 {
	double a = 0, b = 0;

	double product();
}
