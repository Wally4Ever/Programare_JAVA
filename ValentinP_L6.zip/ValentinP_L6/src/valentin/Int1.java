package valentin;

public interface Int1 {
	int a = 0, b = 0;

	int sum();
}
