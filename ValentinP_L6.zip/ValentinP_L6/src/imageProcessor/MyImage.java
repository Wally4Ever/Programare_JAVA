package imageProcessor;

import java.awt.Color;
import java.util.Random;

/*Define a Java package named imageProcessor which contains a class called MyImage. The class has all the necessary 
methods used for initializing and modifying the values from a m x n pixels matrix. Each pixel is an instance of another 
class named Pixel (also included in the package) which contains 3 integer variables R, G and B with possible values 
between 0 and 255.
The class MyImage defines methods for:
- cancelling the pixels that have the RGB values below some values received as parameters
- deleting the R G or B components from all the pixels
- transforming the pixels into grayscale tones by using the formula 0.21 R + 0.71 G + 0.07 B. The new R G and B 
components will be equal with this formula’s results.
Note: each operation is timed.
Import the defined package into a Java application that creates a MyImage instance. The program generates randomly 
the values for the pixels’ components. Apply the methods stored inside the class upon the created instance. Display the 
results and the necessary amount of time specific to each operation*/
public class MyImage {

	public int m;
	public int n;
	public Pixel[][] mat;

	public MyImage(int m, int n) {
		this.m = m;
		this.n = n;
		mat = new Pixel[m][n];
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				mat[i][j] = getRand();
			}
		}

	}

	public void displayImage() {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				Color obj = new Color(mat[i][j].getR(), mat[i][j].getG(), mat[i][j].getB());

				System.out.print(obj.toString() + "  ");
			}
			System.out.println();
		}
	}

	public void grayscale() {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				double r = 0.21 * mat[i][j].getR();
				double g = 0.71 * mat[i][j].getG();
				double b = 0.07 * mat[i][j].getB();
				double gray = r + b + g;
				mat[i][j].setR((int) gray);
				mat[i][j].setG((int) gray);
				mat[i][j].setB((int) gray);
			}
		}
	}

	public void deleteComponent(char x) {
		switch (x) {
		case 'r': {
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					mat[i][j].setR(0);
				}
			}
			break;
		}

		case 'g': {
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					mat[i][j].setG(0);
				}
			}
			break;
		}
		case 'b': {
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					mat[i][j].setB(0);
				}
			}
			break;
		}
		default: {
			System.out.println("Wrong color!");
			break;
		}
		}
	}

	public void cancelPixel(int r, int g, int b) {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				if (mat[i][j].getR() < r && mat[i][j].getG() < g && mat[i][j].getB() < b) {
					mat[i][j].setR(0);
					mat[i][j].setG(0);
					mat[i][j].setB(0);
				}
			}
		}
	}

	public Pixel getRand() {
		Random a = new Random();
		int x = a.nextInt(255);
		int y = a.nextInt(255);
		int z = a.nextInt(255);
		return new Pixel(x, y, z);
	}
}
