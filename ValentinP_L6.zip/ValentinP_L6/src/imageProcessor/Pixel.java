package imageProcessor;

/*Define a Java package named imageProcessor which contains a class called MyImage. The class has all the necessary 
methods used for initializing and modifying the values from a m x n pixels matrix. Each pixel is an instance of another 
class named Pixel (also included in the package) which contains 3 integer variables R, G and B with possible values 
between 0 and 255.
The class MyImage defines methods for:
- cancelling the pixels that have the RGB values below some values received as parameters
- deleting the R G or B components from all the pixels
- transforming the pixels into grayscale tones by using the formula 0.21 R + 0.71 G + 0.07 B. The new R G and B 
components will be equal with this formula’s results.
Note: each operation is timed.
Import the defined package into a Java application that creates a MyImage instance. The program generates randomly 
the values for the pixels’ components. Apply the methods stored inside the class upon the created instance. Display the 
results and the necessary amount of time specific to each operation*/
public class Pixel {
	private int r, g, b;

	Pixel(int r, int g, int b) {
		assert ((r > 255) || (r < 0)) : "input error at red color: " + r;
		assert ((g > 255) || (g < 0)) : "input error at green color: " + g;
		assert ((b > 255) || (b < 0)) : "input error at blue color: " + b;
		this.setR(r);
		this.setG(g);
		this.setB(b);
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

}
