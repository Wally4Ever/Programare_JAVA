package main;

import valentin.Class1;

public class Class2 extends Class1 {

	public Class2(double a, double b) {
		super(a, b);
	}

	public int sum() {
		return (int) (a + b);
	}

	public double product() {
		return a * b;
	}

}