package main;

import java.util.Scanner;

public class ValentinP_L6_3 {

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter 2 numbers: ");
		double a, b;
		a = scanner.nextDouble();
		b = scanner.nextDouble();
		Class2 object = new Class2(a, b);

		System.out.println("The sum of the numbers is: " + object.sum());
		System.out.println("The product of the number is " + object.product());

	}
}
