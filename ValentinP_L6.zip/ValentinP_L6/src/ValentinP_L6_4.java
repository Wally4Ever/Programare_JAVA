
public class ValentinP_L6_4 {
	public static void main(String[] args) {
		Methods object = new Methods();
		try {
			object.a();
		} catch (SmallerException e) {
			e.printStackTrace();
			System.out.println("Lil' tiny error UwU");
		} catch (SuperException e) {
			e.printStackTrace();
			System.out.println("SUPER ERROR EVERYTHING BR0KEN");
		}

		try {
			object.b();
		} catch (SmallerException e) {
			e.printStackTrace();
			System.out.println("Lil' tiny error UwU");
		} catch (SuperException e) {
			e.printStackTrace();
			System.out.println("SUPER ERROR EVERYTHING BR0KEN");
		}
		System.out.println("HeHe!");
	}
}
