import java.util.Scanner;
/*Write an application which checks the Romanian vehicle registration numbers. Their format is the following: 
[L{L}][NN{N}][LLL], where L represents a letter, N a digit, and the curly braces represent the fact that for Bucharest the 
number is composed of a single letter in the first group, and the digit group can be composed of 3 digits. Implement a 
method which checks the registration numbers and throw exceptions (instances of specialized exception classes) specific 
to each error which may occur upon check-up (specialized messages). For example, if the county letters group is 
composed of 2 letters, the digit group cannot be of size 3. The last letters group cannot contain "I" and "O" on the first 
and last position.*/
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValentinP_L6_8 {
	private static Scanner kb = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter the number plates from your car with '-' between them: ");
		String numberPlate = kb.next();
		LicencePlate object = new LicencePlate(numberPlate);
		if (object.isValid()) {
			System.out.println("Good");
		} else {
			System.out.println("WRONG!");
		}
	}

}

class LicencePlate {
	private String plate;

	public LicencePlate(String plate) {
		this.plate = plate;
	}

	public String getPlate() {
		return plate;
	}

	public void setPlate(String plate) {
		this.plate = plate;
	}

	public boolean isValid() {
		if (!validForm()) {
			System.out.println("Incorrect!\nL{L}-NN{N}-LLL");
			try {
				throw new PlateEx("Incorrect!");
			} catch (PlateEx ex) {
				ex.printStackTrace();
				return false;
			}
		}
		StringTokenizer tok = new StringTokenizer(plate, "-");
		String region = tok.nextToken();
		String nr = tok.nextToken();
		String id = tok.nextToken();
		try {
			if (!region.equals("B")) {
				if (region.length() != 2)
					throw new PlateEx("Region is 2 letters!");
				else if (nr.length() == 3)
					throw new PlateEx("Only Bucharest has 3 numbers!");
				else {
					if ((id.charAt(0) == 'I') || (id.charAt(0) == 'O') || (id.charAt(2) == 'I')
							|| (id.charAt(2) == 'O'))
						throw new PlateEx("No 'I' or 'O' on first or last position!");
				}
			} else {
				if ((id.charAt(0) == 'I') || (id.charAt(0) == 'O') || (id.charAt(2) == 'I') || (id.charAt(2) == 'O'))
					throw new PlateEx("No 'I' or 'O' on first or last position!");
			}

		} catch (PlateEx ex) {
			ex.printStackTrace();
			return false;
		}

		return true;
	}

	private boolean validForm() {
		String REGEX = "^[A-Za-z]{1,2}-[0-9]{2,3}-[A-Za-z]{3}$";
		Pattern pattern = Pattern.compile(REGEX);
		Matcher matcher = pattern.matcher(getPlate());
		return matcher.matches();
	}
}

class PlateEx extends Exception {

	public PlateEx(String message) {
		super(message);
	}

}