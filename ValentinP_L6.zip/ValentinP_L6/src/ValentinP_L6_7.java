import imageProcessor.MyImage;

/*Define a Java package named imageProcessor which contains a class called MyImage. The class has all the necessary 
methods used for initializing and modifying the values from a m x n pixels matrix. Each pixel is an instance of another 
class named Pixel (also included in the package) which contains 3 integer variables R, G and B with possible values 
between 0 and 255.
The class MyImage defines methods for:
- cancelling the pixels that have the RGB values below some values received as parameters
- deleting the R G or B components from all the pixels
- transforming the pixels into grayscale tones by using the formula 0.21 R + 0.71 G + 0.07 B. The new R G and B 
components will be equal with this formula’s results.
Note: each operation is timed.
Import the defined package into a Java application that creates a MyImage instance. The program generates randomly 
the values for the pixels’ components. Apply the methods stored inside the class upon the created instance. Display the 
results and the necessary amount of time specific to each operation*/
public class ValentinP_L6_7 {
	public static void main(String[] args) {
		MyImage poza = new MyImage(3, 3);
		poza.displayImage();

		poza.cancelPixel(200, 90, 130);
		System.out.println();
		poza.displayImage();

		poza.deleteComponent('g');
		System.out.println();
		poza.displayImage();

		poza.grayscale();
		System.out.println();
		poza.displayImage();
	}
}
