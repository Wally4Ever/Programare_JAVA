/*Write a Java app which uses the synchronized method acces for mutual exclusion. Create 3 separate threads which
simultaneously call methods to increment and decrement a separate class' class variable. Check if the results are what
you expect them to be. Remove the synchronized blocks and reevaluate the results. */

public class ValentinP_L9_4 {
	public static void main(String[] args) {
		Thread t1 = new Thread(() -> {
			for (int i = 0; i < 10000; i++) {
				Sync.increment();
			}
		});

		Thread t2 = new Thread(() -> {
			for (int i = 0; i < 10000; i++) {
				Sync.decrement();
			}
		});

		Thread t3 = new Thread(() -> {
			for (int i = 0; i < 10000; i++) {
				Sync.increment();
			}
		});

		t1.start();
		t2.start();
		t3.start();

		try {
			t1.join();
			t2.join();
			t3.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Count (synchronized): " + Sync.getCount());

		Sync.count = 0;
		Thread t4 = new Thread(() -> {
			for (int i = 0; i < 10000; i++) {
				Sync.count++;
			}
		});
		Thread t5 = new Thread(() -> {
			for (int i = 0; i < 10000; i++) {
				Sync.count--;
			}
		});
		Thread t6 = new Thread(() -> {
			for (int i = 0; i < 10000; i++) {
				Sync.count++;
			}
		});

		t4.start();
		t5.start();
		t6.start();
		try {
			t4.join();
			t5.join();
			t6.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Count (not synchronized): " + Sync.getCount());
	}
}

class Sync {
	public static int count = 0;

	public synchronized static void increment() {
		count++;
	}

	public synchronized static void decrement() {
		count--;
	}

	public static int getCount() {
		return count;
	}
}
