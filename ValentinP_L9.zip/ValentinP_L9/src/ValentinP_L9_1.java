import java.util.Scanner;

/*Write a Java application which contains a class which implements the Runnable interface. The class' constructor sets
the name of the instantiated object. Also, there is a class variable which counts the number of instantiated objects from
that class. The run( ) method of the class will print the object's name for a number of times equal to the counter's value,
each printing being delayed 1000 ms. 
In a distinct class, create multiple threads built from separate objects of the previously described class. Analyze the
results.
*/
public class ValentinP_L9_1 {
	public static Scanner kb;

	public static void main(String[] args) {

		kb = new Scanner(System.in);
		System.out.print("Name: ");
		String in = kb.next();
		Thread first = new Thread(new Run(in));

		System.out.print("Name: ");
		in = kb.next();
		Thread second = new Thread(new Run(in));

		System.out.print("Name: ");
		in = kb.next();
		Thread third = new Thread(new Run(in));

		first.start();
		second.start();
		third.start();
	}

}

class Run implements Runnable {
	String name;
	static int counter = 0;

	public Run(String name) {
		this.name = name;
		counter++;
	}

	public void run() {
		for (int i = 0; i < counter; i++) {
			try {
				System.out.println(name);
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}
}