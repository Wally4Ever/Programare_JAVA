import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/*Write a Java application with a thread that writes some information into a file while another thread reads the written
data and displays it on the screen. Synchronize the threads.
*/

public class ValentinP_L9_6 {
	private static final Object monitor = new Object();
	private static boolean dataReady = false;

	public static void main(String[] args) {
		Write writer = new Write();
		Read reader = new Read();
		writer.start();
		reader.start();
	}

	private static class Write extends Thread {
		@Override
		public void run() {
			synchronized (monitor) {
				try {
					String data = "Buna dimineata, viata mea!\n Te astept la o cafea!";
					Path file = Paths.get("E:\\POLI\\Programare\\ValentinP_L9\\src\\data.txt");
					Files.write(file, data.getBytes(StandardCharsets.UTF_8));
					dataReady = true;
					monitor.notify();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static class Read extends Thread {
		@Override
		public void run() {
			synchronized (monitor) {
				try {
					while (!dataReady) {
						monitor.wait();
					}
					Path file = Paths.get("E:\\POLI\\Programare\\ValentinP_L9\\src\\data.txt");
					Files.lines(file).forEach(System.out::println);

				} catch (IOException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
