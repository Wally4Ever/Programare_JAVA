import java.util.Scanner;
/* Write a class for determining a certain value from Fibonacci’s array. The class has 2 methods, one for calculating and
the other for displaying the desired value. Use a synchronized multithreading mechanism in which one process displays
all the Fibonacci numbers smaller than the desired value computed by the other process.*/

public class ValentinP_L9_3 {

	public static Scanner kb;

	public static void main(String[] args) {
		kb = new Scanner(System.in);
		System.out.print("Nth nr from fib sequence: ");
		int nr = kb.nextInt();
		kb.close();

		if (nr < 0)
			System.out.println("Wrong!");
		else {
			try {
				Thread fibThread = new Thread(new Fibonacci(nr));
				Thread outThread = new Extra();

				fibThread.start();
				outThread.start();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
}

class Fibonacci implements Runnable {
	public static volatile int fn = 0;
	public static volatile boolean isPrinted = false;

	int index;

	public Fibonacci(int index) {
		this.index = index;
	}

	public void run() {
		calculateDesiredNumber();
	}

	public synchronized void calculateDesiredNumber() {
		if (index == 1) {
			dispNr(0);
		} else if (index == 2) {
			dispNr(1);
		} else {
			try {
				Thread.sleep(500);
				System.out.println(1);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			int n1 = 0, n2 = 1;
			for (int i = 2; i < index; i++) {
				isPrinted = false;
				fn = n1 + n2;
				n1 = n2;
				n2 = fn;
				while (!isPrinted) {
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
			dispNr(fn);
		}

	}

	public void dispNr(int nr) {
		System.out.println("Desired number: " + nr);
	}

}

class Extra extends Thread {

	public Extra() {
		setDaemon(true);
	}

	public void run() {
		while (true) {
			while (Fibonacci.isPrinted) {
				try {
					Thread.sleep(500);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			System.out.println(Fibonacci.fn);
			Fibonacci.isPrinted = true;
		}
	}
}