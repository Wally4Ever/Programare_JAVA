import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*There is an urn which contains 1000 losing tickets and 1 winning ticket. There are N people around the urn (N is read
from the keyboard) which simultaneously extract tickets from it. The tickets are not placed back into the urn. When one
person extracts the winning ticket, the game stops.
Alternatives: 1) the persons extract the tickets in a predefined order; 2) the tickets are placed back into the urn.*/
public class ValentinP_L9_7 {
	public static Scanner kb;

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		System.out.println("Number of players: ");
		int nr = kb.nextInt();
		kb.close();
		List<Integer> urn = new ArrayList<>();
		for (int i = 0; i < 1000; i++) {
			urn.add(0);
		}
		urn.add(1);

		Collections.shuffle(urn);

		int winner = -1;
		for (int i = 0; i < nr; i++) {
			int ticket = urn.remove(0);
			System.out.println((i + 1) + " drew " + (ticket == 0 ? "a losing" : "the winning") + " ticket.");
			if (ticket == 1) {
				winner = i + 1;
				break;
			}
		}

		if (winner != -1) {
			System.out.println("Player " + winner + " wins!");
		} else {
			System.out.println("Everyone lost");
		}
	}
}
