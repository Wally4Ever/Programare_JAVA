import java.math.BigInteger;
import java.util.Scanner;

/*. Write a Java app which computes the greatest common divisor for large numbers (>100.000). The app will continuosly
read from the keyboard pairs of numbers and launch threads for each of the pairs. The results will be displayed in the
console as soon as they are available.
*/
public class ValentinP_L9_5 {
	public static Scanner kb;

	public static void main(String[] args) {
		Scanner kb = new Scanner(System.in);
		BigInteger n1, n2;
		System.out.print("Enter 2 numbers: ");
		n1 = kb.nextBigInteger();
		n2 = kb.nextBigInteger();
		kb.close();
		try {
			MyThread t1 = new MyThread(n1, n2);
			t1.start();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}

class MyThread extends Thread {
	BigInteger n1, n2;

	public MyThread(BigInteger n1, BigInteger n2) {
		this.n1 = n1;
		this.n2 = n2;
	}

	@Override
	public void run() {
		System.out.println("GCD for " + n1 + " and " + n2 + " is: " + calcGCD());
	}

	public BigInteger calcGCD() {
		return n1.gcd(n2);
	}

}